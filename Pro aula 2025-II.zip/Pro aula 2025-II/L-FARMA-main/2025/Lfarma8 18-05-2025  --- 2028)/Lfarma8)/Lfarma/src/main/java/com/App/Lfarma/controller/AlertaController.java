
package com.App.Lfarma.controller;

import com.App.Lfarma.service.AlertaService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/alertas")
@CrossOrigin(origins = "*") // Permite llamadas desde cualquier origen (útil para frontend)
public class AlertaController {

    private final AlertaService alertaService;

    // Constructor con inyección de dependencia
    public AlertaController(AlertaService alertaService) {
        this.alertaService = alertaService;
    }

    // Endpoint GET para obtener alertas
    @GetMapping
    public Map<String, Object> getAlertas() {
        return alertaService.obtenerAlertas();
    }
}
