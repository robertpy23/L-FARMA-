package com.App.Lfarma.controller;

import com.App.Lfarma.service.AlertaService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/alertas")
@CrossOrigin(origins = "*") // 👈 Esto permite llamadas desde tu frontend
public class AlertaController {

    private final AlertaService alertaService;

    public AlertaController(AlertaService alertaService) {
        this.alertaService = alertaService;
    }

    // Endpoint para consultar las alertas
    @GetMapping
    public Map<String, Object> getAlertas() {
        return alertaService.obtenerAlertas();
    }
}

