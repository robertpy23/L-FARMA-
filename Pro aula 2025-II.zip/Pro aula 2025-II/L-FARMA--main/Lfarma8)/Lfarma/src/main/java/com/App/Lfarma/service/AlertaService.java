
package com.App.Lfarma.service;

import com.App.Lfarma.entity.Producto;
import com.App.Lfarma.repository.ProductoRepository;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class AlertaService {

    private final ProductoRepository productoRepository;

    public AlertaService(ProductoRepository productoRepository) {
        this.productoRepository = productoRepository;
    }

    public Map<String, Object> obtenerAlertas() {
        Map<String, Object> alertas = new HashMap<>();

        // 🚨 Stock bajo (ej: ≤ 5 unidades)
        List<Producto> stockBajo = productoRepository.findByCantidadLessThanEqual(5);

        // 🚨 Vencimientos próximos (ej: en los próximos 15 días)
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 15);
        Date fechaLimite = cal.getTime();

        List<Producto> vencimientos = productoRepository.findByFechaVencimientoBefore(fechaLimite);

        alertas.put("stock", stockBajo);
        alertas.put("vencimiento", vencimientos);
        alertas.put("total", stockBajo.size() + vencimientos.size());

        return alertas;
    }
}
