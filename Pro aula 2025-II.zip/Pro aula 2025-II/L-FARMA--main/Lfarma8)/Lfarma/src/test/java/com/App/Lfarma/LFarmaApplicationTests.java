package com.App.Lfarma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LFarmaApplicationTests {

	@Test
	void contextLoads() {
	}

}
